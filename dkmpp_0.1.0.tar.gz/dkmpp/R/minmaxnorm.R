#' Column-wise min-max normalization.
#'
#' This function allows you to perform min-max normalization to each column of a given matrix or a data frame
#' @param mydata A matrix or a data frame of numeric values.
#' @export
#' @author Nidheesh N. <nidheesh.n@gmail.com>
#' @return A copy of the input matrix or data frame with each column min-max normalized.
#' @examples
#' m = matrix(sample(1:100, 25),5,5)
#' m
#' minmaxnorm(m)

##############################################################################################
# column-wise min-max normalization of data frame/ matrix
##############################################################################################
minmaxnorm <- function(mydata){
  minmy <- apply(mydata, 2, min)
  maxmy <- apply(mydata, 2, max)
  denommy <- maxmy - minmy
  cols <- numeric()
  if(any(denommy == 0)){
    cols <- which(denommy == 0)
    denommy[cols] <- 1
  }
  mydata <- sweep(mydata, 2, minmy, FUN = "-")
  mydata <- sweep(mydata, 2, denommy, FUN = "/")
  if(length(cols) > 0) mydata[, cols] <- 1
  return(mydata)
}
