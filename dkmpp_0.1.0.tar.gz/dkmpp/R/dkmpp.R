#' Density K-Means++
#'
#' This function is a density based, deterministic variant of the K-Means clustering algorithm.
#' @param mydata A data frame with rows representing the data points to be clustered.
#' @param k An integer indicating the desired number of clusters.
#' @return A clustering vector indicating the cluster number assigned to each data point.
#' @export
#' @importFrom "vegan" "spantree"
#' @importFrom "stats" "IQR" "dist" "kmeans" "quantile"
#' @author Nidheesh N. <nidheesh.n@gmail.com>
#' @examples
#' data(iris)
#' dkmpp(iris[,1:4], 3)
#' table(dkmpp(minmaxnorm(iris[,1:4]), 3))


dkmpp <- function(mydata, k){

  #################################################################################
  # computing the distance between every pair of points
  #################################################################################
  M <- as.matrix(dist(mydata))
  M <- M / max(M)   # min-max normalization of distances

  #################################################################################
  # MST heuristic for eps calculation
  #################################################################################
  mstedglengs <- spantree(dist(mydata))$dist
  eps <-  min(max(mstedglengs), 3.0 * IQR(mstedglengs) + quantile(mstedglengs, probs = c(0.75)))

  #################################################################################
  # rho computation:
  #################################################################################
  n <- nrow(mydata)
  rho <- vector("double", n)
  for(i in 1:n){
    epsnbrsi <- setdiff(which(M[ ,i] <= eps), i) #epsilon neghbors of data point i
    for(j in epsnbrsi){
      rho[i] <- rho[i] + exp(-1 * M[i, j] / eps)
    }
  }

  #################################################################################
  # min-max normalization of rho
  #################################################################################
  maxrho <- max(rho)
  minrho <- min(rho)
  rho <- rho - minrho
  rho <- rho / (maxrho - minrho)

  #################################################################################
  # Finding k initial centroids
  #################################################################################
  p <- which.max(rho) # highest density point
  prospect <- vector("double", n)
  C <- p                                        # C = {p}
  mind2cent <- rep(Inf, n)
  while(length(C) < k){
    for(j in 1:n){
      mind2cent[j] <- min(M[j, p], mind2cent[j])
      prospect[j] <- rho[j] * mind2cent[j]
    }
    p <- which.max(prospect) # point with maximum prospect = a centroid
    C <- union(C, p) # Added center to C
  }

  #################################################################################
  # call kmeans(Hartigan-Wong) with initial centroids in C
  #################################################################################
  return(kmeans(mydata, mydata[C, ], iter.max = 50)$cluster)
}
